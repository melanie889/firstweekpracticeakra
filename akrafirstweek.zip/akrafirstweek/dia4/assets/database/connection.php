<?php
$host = "localhost";
$usuario = "root";
$contrasena = "";
$basedatos = "formulario";
$puerto = 3306; 

$conexion = mysqli_connect($host, $usuario, $contrasena, $basedatos, $puerto);

if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

mysqli_set_charset($conexion, "utf8mb4");
?>

