-- Crear la base de datos si no existe
CREATE DATABASE IF NOT EXISTS usuarios;

-- Usar la base de datos creada
USE usuarios;

-- Crear la tabla usuarios si no existe
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    email VARCHAR(100),
    password_hash VARCHAR(255),
    edad INT,
    genero VARCHAR(20),
    pais VARCHAR(50),
    intereses TEXT,
    comentarios TEXT,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE IF NOT EXISTS accesos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    fecha_acceso TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip VARCHAR(45),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);


INSERT INTO usuarios (nombre, email, password_hash, edad, genero, pais, intereses, comentarios) VALUES
('Juan Pérez', 'juan.perez@example.com', 'hashed_password_juan', 30, 'Masculino', 'España', 'Viajes, Fotografía', 'Cliente frecuente'),
('María Gómez', 'maria.gomez@example.com', 'hashed_password_maria', 25, 'Femenino', 'México', 'Aventura, Cultura', NULL),
('Luis Fernández', 'luis.fernandez@example.com', 'hashed_password_luis', 40, 'Masculino', 'Argentina', 'Deportes, Gastronomía', 'Prefiere destinos rurales');


INSERT INTO accesos (usuario_id, fecha_acceso, ip) VALUES
(1, '2025-05-26 09:00:00', '192.168.1.10'),
(1, '2025-05-27 14:30:00', '192.168.1.11'),
(2, '2025-05-26 11:15:00', '192.168.1.12'),
(3, '2025-05-25 20:00:00', '10.0.0.5');
