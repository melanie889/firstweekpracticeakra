<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Document</title>
  <link rel="stylesheet" href="../assets/css/sytle.css" />

  <style>
   
  </style>
</head>

<body>


  <header>
    <div class="logo">
      <img src="img/gallary.png" alt="Logo">
     
    </div>
    <div style="display: flex; align-items: center; gap: 15px;">
      <nav>
        <a href="https://picsum.photos/images">Home</a>
        <a href="https://picsum.photos/">Gallery</a>
        <a href="../dia4/assets/user/form1.php">Contact</a>
        <a href="https://picsum.photos/images">About</a>
      </nav>
      <a href="../assets/user/login.php" class="login-btn">login</a>


    </div>
  </header>

   <main>
 
    <div class="image-section">
      <h2>Featured Images-Model-flexbox</h2>
      <p>Click on the images to learn more about them.</p>
    <p>Lorem Picsum o Picsum Photos es un servicio de imágenes API simple de usar, sin regalías y gratuitos que puedes usar para buscar y usar imágenes aleatorias o de marcadores de posición en tus sitios web.
      A continuación se presentan las características de Lorem Picsum</p>
      <div class="image-container">
        <div class="image">
          <img src="img/imge.jpg" alt="Image 1">
          <h3>creek-river </h3>
          <p>I am ten years old, and I read the article while camping by a creek.</p><br>
           <a href=" https://picsum.photos/images" target="_blank" class="link">read more</a><br>
        </div>
        <div class="image">
          <img src="img/imge3.jpg" alt="Image 2">
          <h3>sea Urchin Sea  </h3>
          <p>Sea urchins or urchins (/ˈɜːrtʃɪnz/) are echinoderms in the class Echinoidea. About 950 species live on the seabed, inhabiting all oceans and depth zones from the intertidal zone to deep seas of 5,000 m (16,000 ft)</p><br>
          <a href=" https://picsum.photos/images" target="_blank" class="link">read more</a>
        </div>
        <div class="image">
          <img src="img/imge4.jpg" alt="Image 3">
          <h3>Cámaras y equipos ópticos</h3>
          <p>La cámara fotográfica es un dispositivo tecnológico que tiene como objetivo o función principal el tomar imágenes quietas de situaciones, personas, paisajes o eventos para mantener memorias visuales de los mismos. Las cámaras fotográficas son las responsables del nacimiento de dos ciencias o artes: la fotografía y, posteriormente, el cine. </p><br>
           <a href=" https://picsum.photos/images" target="_blank" class="link">read more</a>
        </div>
        <div class="image">
          <img src="img/imge5.jpg" alt="Image 4">
          <h3>paul javis-Forestry</h3>
          <p>Definición, tipos, beneficios y su impacto en el medio ambiente.</p><br>
          <a href=" https://picsum.photos/images" target="_blank" class="link">read more</a><br>
        </div>
        <div class="image">
          <img src="img/imge6.jpg" alt="Image 5">
          <h3>El lobo</h3>
          <p>El lobo (Canis lupus ;[b] pl.: lobos), también conocido como el lobo gris o lobo gris, es un canino nativo de Eurasia y América del Norte. Más de treinta subespecies de lupus de Canis han sido reconocidas, incluyendo el perro y el dingo, aunque los lobos grises, como se entienden popularmente, sólo comprenden subespecies silvestres que ocurren naturalmente..</p><br>
          <a href=" https://picsum.photos/images" target="_blank" class="link">read more</a>
        </div>
        <div class="image">
          <img src="img/imge7.jpg" alt="Image 6">
          <h3>Mount Everest</h3>
          <p>Mount Everest, towering at a staggering 29,032 feet (8,848 meters), stands as the Earth’s loftiest point, challenging the bold and adventurous. Rising above the majestic Himalayas on the border of Nepal and Tibet, Everest has captivated the human spirit for centuries. Its magnetic allure beckons climbers to undertake the arduous journey to its summit, an endeavor marked by physical prowess and mental fortitude.</p><br>
          <a href=" https://picsum.photos/images" target="_blank" class="link">read more</a>
        </div>
        <div class="image">
          <img src="img/imge8.jpg" alt="Image 7">
          <h3>sea lion</h3>
          <p>he sea lions have six extant and one extinct species (the Japanese sea lion) in five genera. Their range extends from the subarctic to tropical waters of the global ocean in both the Northern </p><br>
          <a href=" https://picsum.photos/images" target="_blank" class="link">read more</a>
        </div>
        <div class="image">
          <img src="img/spicipicImage.jpg" alt="Image 8">
          <h3>el perro</h3>
          <p>The Dog (Spanish: El Perro) is the name usually given to a painting by Spanish artist Francisco de Goya, now in the Museo del Prado, Madrid. It shows the head of a dog gazing upwards.</p><br>
          <a href=" https://picsum.photos/images" target="_blank" class="link">read more</a>
        </div>
      </div>
    </div>
  </main>

  <footer>
    <p>2025 Ipsum Landing Page. All rights reserved.</p>
  </footer>

</body>
</html>

