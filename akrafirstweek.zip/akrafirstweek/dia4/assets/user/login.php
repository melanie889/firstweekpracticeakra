 <?php
session_start();
require_once("../database/connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"] ?? '';
    $email    = $_POST["email"] ?? '';
    $password = $_POST["password"] ?? '';

    if ($username == "admin" && $password == "123") { 
        $_SESSION["username"] = $username;
        header("Location: /dia4/assets/index.php"); 
        exit;
    } else {
        $error = "Usuario o contraseña incorrectos.";
    }
    
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/form.css" />
  <title>Login</title>
</head>
<body>
  <header>
    <div class="logo">
      <img src="../img/gallary.png" alt="Logo">
    </div>
    <div style="display: flex; align-items: center; gap: 15px;">
      <nav>
        <a href="https://picsum.photos/images">Home</a>
        <a href="https://picsum.photos/">Gallery</a>
        <a href="../dia4/assets/user/form1.php">Contact</a>
        <a href="https://picsum.photos/images">About</a>
      </nav>
      <a href="login.php" class="login-btn">login</a>
    </div>
  </header>

  <main>
    <div class="login-container">
      <h2>Iniciar Sesión</h2>

      <?php if (!empty($error)): ?>
        <p class="error"><?php echo $error; ?></p>
      <?php endif; ?>

      <form method="POST">
        <input type="text" name="username" placeholder="Usuario" required>
        <input type="password" name="password" placeholder="Contraseña" required>
        <input type="text" name="email" placeholder="Correo Electrónico" required>
        <input type="submit" value="Iniciar Sesión">
        <p><a href="../logout.php">Cerrar sesión</a></p>
        <p>¿No tienes una cuenta? <a href="register.php">Regístrate aquí</a></p>
      </form>
    </div>
  </main>
</body>
</html>
