<?php
session_start();
session_destroy();
header("Location:  /dia4/assets/index.php");
exit();

