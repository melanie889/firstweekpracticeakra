<?php
session_start();
require_once("../database/connection.php");

$nombre = $email = $edad = $genero = $pais = $comentarios = "";
$intereses_array = [];
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (
        isset($_POST['name'], $_POST['email'], $_POST['password'], $_POST['confirm_password'], $_POST['age'],
        $_POST['gender'], $_POST['country'], $_POST['textarea'], $_POST['terms'])
    ) {
        $nombre = mysqli_real_escape_string($conexion, $_POST['name']);
        $email = mysqli_real_escape_string($conexion, $_POST['email']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];

        if ($password !== $confirm_password) {
            $mensaje = "Las contraseñas no coinciden.";
        } else {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $edad = (int)$_POST['age'];
            $genero = mysqli_real_escape_string($conexion, $_POST['gender']);
            $pais = mysqli_real_escape_string($conexion, $_POST['country']);
            $comentarios = mysqli_real_escape_string($conexion, $_POST['textarea']);
            $intereses_array = isset($_POST['interests']) ? $_POST['interests'] : [];
            $intereses = mysqli_real_escape_string($conexion, implode(',', $intereses_array));

            $sql = "INSERT INTO usuarios (nombre, email, password, edad, genero, pais, intereses, comentarios) 
                    VALUES ('$nombre', '$email', '$password_hash', $edad, '$genero', '$pais', '$intereses', '$comentarios')";

            if (mysqli_query($conexion, $sql)) {
                $_SESSION['register'] = true;
                header("Location: login.php");
                exit;
            } else {
                $mensaje = "Error al registrar: " . mysqli_error($conexion);
            }
        }
    } else {
        $mensaje = "Todos los campos son obligatorios y debes aceptar los términos.";
    }
}
mysqli_close($conexion);
?>


  <!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Formulario de Registro</title>
  <link rel="stylesheet" href="../css/register.css">
</head>
<body>
  <header>
    <div class="logo">
      <img src="../img/gallary.png" alt="Logo">
    </div>
    <div style="display: flex; align-items: center; gap: 15px;">
      <nav>
        <a href="https://picsum.photos/images">Home</a>
        <a href="https://picsum.photos/">Gallery</a>
        <a href="../dia4/assets/user/form1.php">Contact</a>
        <a href="https://picsum.photos/images">About</a>
      </nav>
      <a href="../assets/user/login.php" class="login-btn">login</a>
    </div>
  </header>

  <main>
    <form method="post">
      <h2>Formulario de Registro</h2>

      <?php if ($mensaje): ?>
        <p style="color: <?= strpos($mensaje, 'éxito') !== false ? 'green' : 'red' ?>"><?= htmlspecialchars($mensaje) ?></p>
      <?php endif; ?>

      <label for="name">Nombre completo:</label>
      <input type="text" id="name" name="name" required value="<?= htmlspecialchars($nombre) ?>">

      <label for="email">Correo electrónico:</label>
      <input type="email" id="email" name="email" required value="<?= htmlspecialchars($email) ?>">

      <label for="password">Contraseña:</label>
      <input type="password" id="password" name="password" required>

      <label for="confirm_password">Confirmar contraseña:</label>
      <input type="password" id="confirm_password" name="confirm_password" required>

      <label for="age">Edad:</label>
      <input type="number" id="age" name="age" required value="<?= htmlspecialchars($edad) ?>">

      <label for="gender">Género:</label>
      <select id="gender" name="gender" required>
        <option value="">Seleccione...</option>
        <option value="male" <?= $genero === "male" ? "selected" : "" ?>>Masculino</option>
        <option value="female" <?= $genero === "female" ? "selected" : "" ?>>Femenino</option>
        <option value="other" <?= $genero === "other" ? "selected" : "" ?>>Otro</option>
      </select>

      <label for="country">País:</label>
      <select id="country" name="country" required>
        <option value="">Seleccione...</option>
        <option value="mx" <?= $pais === "mx" ? "selected" : "" ?>>México</option>
        <option value="es" <?= $pais === "es" ? "selected" : "" ?>>España</option>
        <option value="ar" <?= $pais === "ar" ? "selected" : "" ?>>Argentina</option>
        <option value="co" <?= $pais === "co" ? "selected" : "" ?>>Colombia</option>
        <option value="other" <?= $pais === "other" ? "selected" : "" ?>>Otro</option>
      </select>

      <label>Intereses:</label>
      <div class="checkbox-group">
        <label><input type="checkbox" name="interests[]" value="Deporte" <?= in_array("Deporte", $intereses_array) ? "checked" : "" ?>>Deporte</label>
        <label><input type="checkbox" name="interests[]" value="Arte" <?= in_array("Arte", $intereses_array) ? "checked" : "" ?>>Arte</label>
        <label><input type="checkbox" name="interests[]" value="Tecnología" <?= in_array("Tecnología", $intereses_array) ? "checked" : "" ?>>Tecnología</label>
      </div>

      <label for="textarea">Comentarios adicionales:</label>
      <textarea id="textarea" name="textarea"><?= htmlspecialchars($comentarios) ?></textarea>

      <div class="terms">
        <label><input type="checkbox" name="terms" required>Acepto condiciones</label>
      </div>

      <div class="botones">
        <input type="submit" value="Enviar">
        <input type="button" value="Volver" onclick="window.location.href='../index.php'">
      </div>
    </form>
  </main>
</body>
</html>
