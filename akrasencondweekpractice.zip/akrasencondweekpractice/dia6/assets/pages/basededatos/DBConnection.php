<?php

try{
    $dsn= 'mysql:host=localhost:3306;dbname=usuarios;
';
    $user = 'root';
    $pass ='';
   
    $pdo = new PDO($dsn, $user, $pass);

} catch (PDOException $e) {
        echo "ERROR DE CONEXION: " . $e->getMessage();
       
        die;
}

