<?php
session_start();
require '../basededatos/DBConnection.php';
$errores = [];

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';
$age = $_POST['age'] ?? '';
$gender = $_POST['gender'] ?? '';
$country = $_POST['country'] ?? '';
$interests = $_POST['interests'] ?? [];
$textarea = $_POST['textarea'] ?? '';
$terms = $_POST['terms'] ?? '';

if ($name == "" || $email == "" || $password == "" || $confirm_password == "" || $age == "" || $gender == "" || $country == "" || $terms == "") {
    $errores[] = "Todos los campos obligatorios deben ser completados.";
}

if ($password !== $confirm_password) {
    $errores[] = "Las contraseñas no coinciden.";
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resultado del Registro</title>
    <!-- Bootstrap 5.3 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <?php if (!empty($errores)) { ?>
            <div class="alert alert-danger">
                <h4>Errores en el formulario:</h4>
                <ul>
                    <?php foreach ($errores as $error) { ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php } ?>
                </ul>
                <a href="formulario.php" class="btn btn-danger mt-3">Volver al formulario</a>
            </div>
        <?php } else { ?>
            <div class="card shadow">
                <div class="card-header bg-success text-white">
                    <h3>Registro exitoso</h3>
                </div>
                <div class="card-body">
                    <p><strong>Nombre:</strong> <?php echo htmlspecialchars($name); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
                    <p><strong>Edad:</strong> <?php echo htmlspecialchars($age); ?></p>
                    <p><strong>Género:</strong> <?php echo htmlspecialchars($gender); ?></p>
                    <p><strong>País:</strong> <?php echo htmlspecialchars($country); ?></p>
                    <p><strong>Intereses:</strong>
                        <?php
                        if (empty($interests)) {
                            echo "Ninguno";
                        } else {
                            echo implode(", ", array_map('htmlspecialchars', $interests));
                        }
                        ?>
                    </p>
                    <p><strong>Comentarios:</strong><br><?php echo nl2br(htmlspecialchars($textarea)); ?></p>
                </div>
                <div class="card-footer text-end">
                    <a href="formulario.php" class="btn btn-primary">Volver al formulario</a>
                </div>
            </div>
        <?php } ?>
    </div>
</body>
</html>
