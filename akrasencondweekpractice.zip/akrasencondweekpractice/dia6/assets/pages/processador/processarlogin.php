<?php
session_start();
require_once("../Database/DBConnection.php"); 
$mensaje = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

  
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username AND password_hash = :password");
    $stmt->execute([
        'username' => $username,
        'password' => $password
    ]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['error_login'] = "";
        header('Location: /akrasencondweekpractice/dia6/ndex.php');
        exit;
    } else {
        $mensaje = "Usuario o contraseña incorrectos";
        $_SESSION['error_login'] = $mensaje;
        header('Location: ../dia6/assets/pages/users/login.php');
        exit;
    }
}
?>
