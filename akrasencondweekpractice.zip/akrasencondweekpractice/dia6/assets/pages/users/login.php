<?php
session_start();
require '../basededatos/DBConnection.php';
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="/akrasencondweekpractice/dia6/assets/css/login.css">
</head>
<body>
<div class="container login-container">
    <div class="row">
        <div class="col-md-6 login-form-1">
            <h3>Login</h3>
            <form method="post" action="../pages/processador/processarLogin.php">
                <div class="form-group">
                    <input type="text" name="username" class="form-control" placeholder="Your username *" value="" />
                </div>
                <div class="form-group">
                    <input type="password" name="password" class="form-control" placeholder="Your Password *" value="" />
                </div>
                <div class="form-group">
                    <input type="submit" class="btnSubmit" value="Login" />
                </div>
            </form>
            <p style="color:red;"><?php echo htmlspecialchars($_SESSION['error_login']); ?></p>
        </div>
        <div class="col-md-6 login-form-2">
            <h3>Signin</h3>
            <form method="post" action="../pages/processador/processarSignin.php">
                <div class="form-group">
                    <input type="text" name="username" class="form-control" placeholder="New username *" value="" />
                </div>
                <div class="form-group">
                    <input type="password" name="password" class="form-control" placeholder="New Password *" value="" />
                </div>
                <div class="form-group">
                    <input disabled type="text" class="form-control" placeholder="Rol: Docente" />
                </div>
                <div class="form-group">
                    <input type="submit" class="btnSubmit" value="Sign In" />
                </div>
            </form>
            <p style="color:red;"><?php echo htmlspecialchars($_SESSION['error_signin']); ?></p>
        </div>
    </div>
</div>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</body>
</html>
