<?php
session_start();
require '../basededatos/DBConnection.php';
session_start();
$_SESSION['loggedin'] = false;
session_unset();
session_destroy();
header('Location: login.php');
exit();
?>
