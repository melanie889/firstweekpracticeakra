<?php

session_start();
require '../basededatos/DBConnection.php';

$mensaje = $_GET['mensaje'] ?? "";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Formulario de Registro</title>
 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #c0c0c0;
        }
        .form-container {
            max-width: 400px;
            margin: 50px auto;
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(255,0,0,0.1);
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2 class="mb-4">Formulario de Registro</h2>

            <?php if (!empty($mensaje)) { ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($mensaje); ?></div>
            <?php } ?>

            <form method="POST" action="process_registration.php">
                <div class="mb-3">
                    <label for="name" class="form-label">Nombre completo</label>
                    <input type="text" class="form-control" id="name" name="name" required />
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Correo electrónico</label>
                    <input type="email" class="form-control" id="email" name="email" required />
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Contraseña</label>
                    <input type="password" class="form-control" id="password" name="password" required />
                </div>

                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Confirmar contraseña</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required />
                </div>

                <div class="mb-3">
                    <label for="age" class="form-label">Edad</label>
                    <input type="number" class="form-control" id="age" name="age" min="1" max="120" required />
                </div>

                <div class="mb-3">
                    <label class="form-label">Género</label><br>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" id="male" value="Masculino" required>
                        <label class="form-check-label" for="male">Masculino</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" id="female" value="Femenino" required>
                        <label class="form-check-label" for="female">Femenino</label>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="country" class="form-label">País</label>
                    <select class="form-select" id="country" name="country" required>
                        <option value="">--Selecciona un país--</option>
                        <option value="México">México</option>
                        <option value="España">España</option>
                        <option value="Argentina">Argentina</option>
                        <option value="Colombia">Colombia</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Intereses</label><br>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="interests[]" value="Deportes">
                        <label class="form-check-label">Deportes</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="interests[]" value="Música">
                        <label class="form-check-label">Música</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="interests[]" value="Lectura">
                        <label class="form-check-label">Lectura</label>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="textarea" class="form-label">Comentarios</label>
                    <textarea class="form-control" id="textarea" name="textarea" rows="4"></textarea>
                </div>

                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="terms" name="terms" required>
                    <label class="form-check-label" for="terms">Acepto los términos y condiciones</label>
                </div>

                <button type="submit" class="btn btn-primary w-100">Registrarse</button>
            </form>
        </div>
    </div>

  
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

