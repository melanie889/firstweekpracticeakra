<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ViajesMundo</title>
     <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
  />
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
  />
  <link href="../dia6/assets/css/styles.css" rel="stylesheet">
    <style>
        body {
            height: 1000px;
            margin: 0;
            font-family: Arial, sans-serif;
            color: #333;
             padding-top: 1px;
            background-color: blue;
        }

        .container {
            max-width: 34000px;
            margin: 0 auto;
            padding: 0 20px;
            box-sizing: border-box;
        }
        .video-header {
  position: relative;
  width: 100%;
  height: 65vh; 
  overflow: hidden;
}

.video-header video {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 100%;
  height: 100%;
  object-fit: cover;
  transform: translate(-50%, -50%);
  z-index: 0;
}

.video-header .video-overlay {
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  z-index: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: white;
  text-align: center;
  padding: 0 20px;
background: rgba(0, 123, 255, 0.3);

}

.video-header h1 {
  font-size: 3rem;
  font-weight: bold;
 
  margin-bottom: 0.5rem;
}

.video-header p {
  font-size: 1.5rem;
background: rgba(0, 123, 255, 0.3);

}

        header {
            background-color: #003366;
            color: white;
            padding: 15px 0;
        }

        header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }

        .logo {
            font-size: 28px;
            font-weight: bold;
        }

        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            flex-wrap: wrap;
        }
        .navbar.position-fixed {
        z-index: 1030;  
}


        nav ul li {
            margin-left: 25px;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
            font-size: 16px;
        }

        nav ul li a:hover {
            text-decoration: underline;
        }

        .hero {
            
            background-size: cover;
            background-position: center;
            height: 65vh;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            color: white;
            position: relative;
            padding: 20px;
        }

        .hero::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
          
            z-index: 1;
        }

        .hero-content {
            position: relative;
            z-index: 2;
        }

        .hero h1 {
            font-size: 48px;
            margin-bottom: 15px;
            font-weight: bold;
        }

        .hero p {
            font-size: 20px;
            margin-bottom: 30px;
            max-width: 600px;
        }

        .cta-button {
            background-color: #FFD700;
            color: #333;
            padding: 15px 30px;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .cta-button:hover {
            background-color: #ffc400;
        }

        .popular-destinations {
            padding: 60px 0;
            background-color: #f8f9fa;
        }

        .popular-destinations h2 {
            text-align: center;
            font-size: 32px;
            margin-bottom: 40px;
            color: #333;
            font-weight: bold;
        }

        .destinations-grid {
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
        }

        .destination-card {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 25px 20px;
            text-align: center;
            width: 300px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            box-sizing: border-box;
        }

        .destination-card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .destination-card h3 {
            font-size: 22px;
            margin-top: 0;
            margin-bottom: 10px;
            color: #333;
            font-weight: bold;
        }

        .destination-card p {
            font-size: 15px;
            color: #555;
            line-height: 1.6;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-top: 40px;
        }

        /* Responsive styles */
        @media (max-width: 768px) {
            header .container {
                flex-direction: column;
                align-items: center;
            }

            nav ul {
                flex-direction: column;
                align-items: center;
                width: 100%;
            }

            nav ul li {
                margin: 10px 0;
            }

            .hero h1 {
                font-size: 36px;
            }

            .hero p {
                font-size: 18px;
            }

            .destinations-grid {
                flex-direction: column;
                align-items: center;
            }

            .destination-card {
                width: 80%;
                max-width: 350px;
            }
        }

        @media (max-width: 480px) {
            .hero {
                height: auto;
                padding: 40px 20px;
            }

            .hero h1 {
                font-size: 28px;
            }

            .hero p {
                font-size: 16px;
            }

            .cta-button {
                padding: 12px 24px;
                font-size: 16px;
            }

            .popular-destinations h2 {
                font-size: 28px;
            }

            .destination-card h3 {
                font-size: 20px;
            }

            .destination-card p {
                font-size: 14px;
            }

            .destination-card {
                width: 90%;
            }
        }
    </style>
</head>
<body>

<header>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark position-fixed w-100">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">ViajesMundo</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="#">Inicio</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Destinos</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Paquetes</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Contacto</a></li>
        </ul>
      </div>
    </div>
  </nav>


  <header class="video-header">
    <video autoplay muted loop>
      <source src="../dia6/assets/img/header.mp4" type="video/mp4" />
      Tu navegador no soporta el video .
    </video>
    <div class="video-overlay">
      <h1>Explora el mundo con nosotros</h1>
      <p>Vive experiencias únicas en cada destino</p>
    </div>
  </header>


<main>
   

    <section class="popular-destinations">
        <div class="container">
            <h2>Destinos Populares</h2>
            <div class="destinations-grid">
                <div class="destination-card">
                    <img src="../dia6/assets/img/paris.png" alt="París">
                    <h3>París</h3>
                    <p>La ciudad del amor te espera con su historia y cultura.</p>
                </div>
                <div class="destination-card">
                    <img src="../dia6/assets/img/tokyo.png" alt="Tokio">
                    <h3>Tokio</h3>
                    <p>Vive la mezcla de tradición y tecnología en Japón.</p>
                </div>
                <div class="destination-card">
                    <img src="../dia6/assets/img/paris.png" alt="paris">

                    <h3>paris</h3>
                    <p>Disfruta del sol, la playa y la alegría brasileña.</p>
                </div>
            </div>
        </div>
    </section>
</main>

<footer>
    <div class="container">
        <p>© 2024 ViajesMundo. Todos los derechos reservados.</p>
    </div>
</footer>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
      <link rel="stylesheet" href=
"https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
    </script>
    <script src=
"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
    </script>
    <script src=
"https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js">
    </script>
 <script>
  window.onload = function() {
    window.scrollTo({ top: 700, behavior: 'smooth' });
  };
</script>


</body>
</html>
</body>
</html>
