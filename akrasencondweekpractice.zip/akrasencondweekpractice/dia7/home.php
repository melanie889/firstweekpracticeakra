<?php require_once "controllerUserData.php"; ?>
<?php 
$email = $_SESSION['email'];
$password = $_SESSION['password'];
if($email != false && $password != false){
    $sql = "SELECT * FROM usertable WHERE email = '$email'";
    $run_Sql = mysqli_query($con, $sql);
    if($run_Sql){
        $fetch_info = mysqli_fetch_assoc($run_Sql);
        $status = $fetch_info['status'];
        $code = $fetch_info['code'];
        if($status == "verified"){
            if($code != 0){
                header('Location: reset-code.php');
            }
        }else{
            header('Location: user-otp.php');
        }
    }
}else{
    header('Location: login-user.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title><?php echo $fetch_info['name'] ?> | ViajesMundo</title>
     <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
  />
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
  />
  <link href="/dia6/assets/css/style.css" rel="stylesheet">
    <style>
       
    </style>
</head>
<body>

<header>
    <div class="top-bar d-flex justify-content-between align-items-center">
  <div class="contact-info d-flex flex-wrap">
    <span><i class="fas fa-map-marker-alt"></i> Melanie Mendez, 89</span>
    <span><i class="fas fa-envelope"></i> info@viajesmundoatraves.es</span>
    <span><i class="fas fa-phone-alt"></i> 964722746</span>
    <span><i class="fab fa-whatsapp"></i> 661748303</span>
  </div>
  <div class="d-flex align-items-center">
    <div class="social-icons me-3">
      <a href="#"><i class="fab fa-facebook-f"></i></a>
      <a href="#"><i class="fab fa-instagram"></i></a>
    </div>
    <div class="auth-links">
      <a href="login.php" class="text-white me-2">Login</a> |
      <a href="logout.php" class="text-white ms-2">Logout</a>
    </div>
  </div>
</div>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark position-fixed w-100">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">ViajesMundo</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="/dia6/page.php">Inicio</a></li>
          <li class="nav-item"><a class="nav-link" href="https://www.istockphoto.com/es/fotograf%C3%ADas-de-stock/destinos-de-viajes?utm_medium=cpc&utm_source=MICROSOFT&utm_campaign=ES_Tail_Photo_ES_DSA&utm_content=Photo_DSA&utm_term=DYNAMIC+SEARCH+ADS&&msclkid=1981504878cd14299e6b387deacea022&gclid=1981504878cd14299e6b387deacea022&gclsrc=3p.ds&gad_source=7">Destinos</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Paquetes</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Contacto</a></li>
           <li class="nav-item"><a class="nav-link" href="#">login</a></li>
        </ul>
      </div>
    </div>
  </nav>


  <header class="video-header">
    <video autoplay muted loop>
      <source src="../dia6/assets/img/header.mp4" type="video/mp4" />
      Tu navegador no soporta el video HTML5.
    </video>
    <div class="video-overlay">
      <h1>Explora el mundo con nosotros</h1>
      <p>Vive experiencias únicas en cada destino</p>
    </div>
  </header>


<main>
   

    <section class="popular-destinations">
        <div class="container">
            <h2>Destinos Populares</h2>
            <div class="destinations-grid">
                <div class="destination-card">
                    <img src="../dia6/assets/img/paris.png" alt="París">
                    <h3>París</h3>
                    <p>La ciudad del amor te espera con su historia y cultura.</p>
                </div>
                <div class="destination-card">
                    <img src="../dia6/assets/img/tokyo.png" alt="Tokio">
                    <h3>Tokio</h3>
                    <p>Vive la mezcla de tradición y tecnología en Japón.</p>
                </div>
                <div class="destination-card">
                    <img src="../dia6/assets/img/paris.png" alt="paris">

                    <h3>paris</h3>
                    <p>Disfruta del sol, la playa y la alegría brasileña.</p>
                </div>
            </div>
        </div>
    </section>
</main>

<footer>
    <div class="container">
        <p>© 2025 ViajesMundo. Todos los derechos reservados.</p>
    </div>
</footer>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
      <link rel="stylesheet" href=
"https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
    </script>
    <script src=
"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
    </script>
    <script src=
"https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js">
    </script>
 <script>
  window.onload = function() {
    window.scrollTo({ top: 700, behavior: 'smooth' });
  };
</script>


</body>
</html>
</body>
</html>
