<?php require_once "controllerUserData.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo $fetch_info['name'] ?> | ViajesMundo</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />

  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
    }

    .video-header {
      position: relative;
      width: 100%;
      height: 100vh;
      overflow: hidden;
    }

    .video-header video {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
      z-index: 0;
    }

    .video-overlay {
      position: absolute;
      top: 10%;
      width: 100%;
      text-align: center;
      color: white;
      z-index: 1;
    }

    .login-form-container {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      z-index: 2;
      background: rgba(255, 255, 255, 0.95);
      padding: 30px;
      border-radius: 10px;
      width: 100%;
      max-width: 400px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
    }

    .top-bar {
      background: #333;
      color: #fff;
      padding: 10px 20px;
      font-size: 14px;
    }

    .top-bar span, .top-bar a {
      margin-right: 15px;
      color: #fff;
    }

    footer {
      text-align: center;
      padding: 60px 20px;
      background: #ddd;
      color: #333;
    }
  </style>
</head>
<body>

  <div class="top-bar d-flex justify-content-between align-items-center">
    <div class="contact-info d-flex flex-wrap">
      <span><i class="fas fa-map-marker-alt"></i> Melanie Mendez, 59</span>
      <span><i class="fas fa-envelope"></i> info@viajesmundoatraves.es</span>
      <span><i class="fas fa-phone-alt"></i> 96472274758</span>
      <span><i class="fab fa-whatsapp"></i> 66174830658</span>
    </div>
    <div class="d-flex align-items-center">
      <div class="social-icons me-3">
        <a href="#"><i class="fab fa-facebook-f"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
      </div>
      <div class="auth-links">
        <a href="login-user.php" class="text-white me-2">Login</a> |
        <a href="logout-user.php" class="text-white ms-2">Logout</a>
      </div>
    </div>
  </div>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark position-sticky top-0 w-100 z-3">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">ViajesMundo</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="/dia6/page.php">Inicio</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Destinos</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Paquetes</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Contacto</a></li>
          <li class="nav-item"><a class="nav-link" href="login-user.php">Login</a></li>
          <li class="nav-item"><a class="nav-link" href="signup-user.php">Signup</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="video-header">
    <video autoplay muted loop>
      <source src="../dia6/assets/img/header.mp4" type="video/mp4" />
      Tu navegador no soporta el video HTML5.
    </video>

    <div class="video-overlay">
      <h1>Explora el mundo con nosotros</h1>
      <p>Vive experiencias únicas en cada destino</p>
    </div>

    <div class="login-form-container">
      <form action="login-user.php" method="POST" autocomplete="">
        <h2 class="text-center">Login Form</h2>
        <p class="text-center">Login with your email and password.</p>
        <?php if (count($errors) > 0): ?>
          <div class="alert alert-danger text-center">
            <?php foreach ($errors as $showerror) echo $showerror; ?>
          </div>
        <?php endif; ?>
        <div class="form-group mb-3">
          <input class="form-control" type="email" name="email" placeholder="Email Address" required value="<?php echo $email ?>">
        </div>
        <div class="form-group mb-3">
          <input class="form-control" type="password" name="password" placeholder="Password" required>
        </div>
        <div class="mb-2 text-end">
          <a href="forgot-password.php">Forgot password?</a>
        </div>
        <div class="form-group mb-3">
          <input class="btn btn-primary w-100" type="submit" name="login" value="Login">
        </div>
        <div class="text-center">
          Not yet a member? <a href="signup-user.php">Signup now</a>
        </div>
      </form>
    </div>
  </header>

  <footer>
    <div class="container">
      <p>© 2025 ViajesMundo. Todos los derechos reservados.</p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
