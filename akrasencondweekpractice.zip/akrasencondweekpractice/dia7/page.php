<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Viajes Mundo a Través</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="/dia6/assets/css/page.css">
 
</head>
<body>


  <div class="header-container">
    <video class="bg-video" autoplay muted loop playsinline>
      <source src="/dia6/assets/img/header.mp4" type="video/mp4" />
      Tu navegador no soporta video en HTML5.
    </video>

    <div class="top-bar">
      <div class="contact-info">
        <span><i class="fas fa-map-marker-alt"></i> Melanie Mendez, 89</span>
        <span><i class="fas fa-envelope"></i> info@viajesmundoatraves.es</span>
        <span><i class="fas fa-phone-alt"></i> 964722741</span>
        <span><i class="fab fa-whatsapp"></i> 661748303</span>
      </div>
      <div class="social-icons">
        <a href="#"><i class="fab fa-facebook-f"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
      </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark navbar-centered">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">viajesmundoatraves.es</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarContent">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0">

            <li class="nav-item"><a class="nav-link active" href="#">INICIO</a></li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="destinosDropdown" role="button" data-bs-toggle="dropdown">DESTINOS</a>
              <ul class="dropdown-menu" aria-labelledby="destinosDropdown">
                <li><a class="dropdown-item" href="#">España</a></li>
                <li><a class="dropdown-item" href="#">Italia</a></li>
                <li><a class="dropdown-item" href="#">Japón</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="viajesDropdown" role="button" data-bs-toggle="dropdown">VIAJES</a>
              <ul class="dropdown-menu" aria-labelledby="viajesDropdown">
                <li><a class="dropdown-item" href="#">Aventura</a></li>
                <li><a class="dropdown-item" href="#">Lujo</a></li>
                <li><a class="dropdown-item" href="#">Familiar</a></li>
              </ul>
            </li>
            <li class="nav-item"><a class="nav-link" href="#">PRESUPUESTOS</a></li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle text-warning" href="#" id="allDropdown" role="button" data-bs-toggle="dropdown">ALL</a>
              <ul class="dropdown-menu" aria-labelledby="allDropdown">
                <li><strong class="dropdown-header">DESTINOS</strong></li>
                <li><a class="dropdown-item" href="#">España</a></li>
                <li><a class="dropdown-item" href="#">Italia</a></li>
                <li><a class="dropdown-item" href="#">Japón</a></li>
                <li><hr class="dropdown-divider" /></li>
                <li><strong class="dropdown-header">VIAJES</strong></li>
                <li><a class="dropdown-item" href="#">Aventura</a></li>
                <li><a class="dropdown-item" href="#">Lujo</a></li>
                <li><a class="dropdown-item" href="#">Familiar</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    
    <div class="video-overlay">
      <h1>Explora el mundo con nosotros</h1>
      <p>Viajes inolvidables a destinos exóticos y culturales</p>
    </div>
  </div>


  <section class="popular-destinations">
        <div class="container">
            <h2>Destinos Populares</h2>
            <div class="destinations-grid">
                <div class="destination-card">
                    <img src="../dia6/assets/img/paris.png" alt="París">
                    <h3>París</h3>
                    <p>La ciudad del amor te espera con su historia y cultura.</p>
                </div>
                <div class="destination-card">
                    <img src="../dia6/assets/img/tokyo.png" alt="Tokio">
                    <h3>Tokio</h3>
                    <p>Vive la mezcla de tradición y tecnología en Japón.</p>
                </div>
                <div class="destination-card">
                    <img src="../dia6/assets/img/paris.png" alt="paris">

                    <h3>paris</h3>
                    <p>Disfruta del sol, la playa y la alegría brasileña.</p>
                </div>
                 <div class="destination-card">
                    <img src="../dia6/assets/img/philippines.png.jpg" alt="philippines">
                    <h3>philippines</h3>
                    <p>Nestled in the heart of Bohol Island, the Chocolate Hills are one of the island’s most iconic natural attractions. This unique landscape of over 1,200 symmetrical mounds, which transform into a rich chocolate hue during the dry season, has long captivated visitors with its surreal beauty and intriguing geological history.</p>
                </div>
                 <div class="destination-card">
                    <img src="../dia6/assets/img/thailandresort.jpg" alt="thailand">
                    <h3>thailand</h3>
                    <p>thailand resort.</p>
                </div>
                 <div class="destination-card">
                    <img src="../dia6/assets/img/toledocathedral.png" alt="Toledo Cathedral spain">
                    <h3>Toledo Cathedral spain</h3>
                    <p>Vive la mezcla de tradición y tecnología en spain.</p>
                </div>
                 <div class="destination-card">
                    <img src="../dia6/assets/img/chocolate-hills-1.png" alt=chocolate hills">
                    <h3>chocoltehills</h3>
                    <p>Vive la mezcla de tradición y tecnología en philippine.</p>
                </div>
                 <div class="destination-card">
                    <img src="../dia6/assets/img/BARCELONA.png" alt="Barcelona">
                    <h3>Barcelona</h3>
                     <p>Vive la mezcla de tradición y tecnología en barelona.</p>
                    
                </div>
                 <div class="destination-card">
                    <img src="../dia6/assets/img/philippinesmayon.png" alt="PHILIPPINES">
                    <h3>Mayon volacano</h3>
                    <p>Vive la mezcla de tradición y tecnología en phillipines.</p>
                </div>
                 <div class="destination-card">
                    <img src="../dia6/assets/img/barcelonacasabatllo.jpg" alt="Tokio">
                    <h3>Casa Batllo Barcelona</h3>
                    <p> The Casa Batllo was originally a house built by the well-renown Catalan architect Antoni Gaudi in the early 20th century. The building quickly became iconic for its original design that incorporates a lot of colors made up mostly of floral designs run all across the two faces of the building, as well as the multi-colored roof that is often compared to a rainbow due to the way that the colors merge and mix. Additionally, there are a lot of theories about the building, such as that it is actually a memorial for Saint George due to the cross in the top left of the building.</p>
                </div>
                 <div class="destination-card">
                    <img src="../dia6/assets/img/alicantespot.png" alt="alicante">
                    <h3>alicante</h3>
                    <p>Guided tour of Vinalopó Castles and Wine Tasting spain</p>
                </div>
                 <div class="destination-card">
                    <img src="../dia6/assets/img/cavealicante.png" alt="alicante">
                    <h3>alicante</h3>
                    <p>Cueva Canelobre and village Busot tour from Alicante and Campello.</p>
                </div>
                    <div class="container mt-5 mb-5">
        <h2 class="text-center mb-4 main-title">Viajes Por España más Populares</h2>

        <ul class="nav nav-tabs justify-content-center mb-5">
            <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#">POPULARES</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">CIRCUITOS</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">COMBINADOS</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">RUTAS EN COCHE</a>
            </li>
        </ul>

        <div class="row">
            <!-- Card 1 -->
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-img-top-container">
                        <img src="https://via.placeholder.com/350x233/E0E0E0/A0A0A0?text=Tenerife+Lanzarote" class="card-img-top" alt="Tenerife y Lanzarote">
                        <div class="card-img-overlay-icon">
                            <i class="fas fa-map-marked-alt"></i>
                        </div>
                    </div>
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title">Tenerife y Lanzarote con coche de alquiler</h5>
                        <p class="card-text small-muted-text">Islas Canarias, 7 días</p>
                        <p class="card-text">A tu aire en coche</p>
                        <p class="card-text">Salida el 1/10/2025 desde Madrid</p>
                        <div class="mt-auto d-flex justify-content-between align-items-center pt-3">
                            <div class="card-bottom-icons">
                                <i class="fas fa-plane"></i>
                                <i class="fas fa-lock ms-2"></i>
                                <i class="fas fa-car ms-2"></i>
                            </div>
                            <div class="price-tag-container">
                                <span class="discount-badge">-34%</span>
                                <span class="original-price">598€</span>
                                <span class="final-price">399€</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-img-top-container">
                        <img src="https://via.placeholder.com/350x233/E0E0E0/A0A0A0?text=Isla+de+Cuento" class="card-img-top" alt="Ruta por la Isla de Cuento">
                        <div class="card-img-overlay-icon">
                             <i class="fas fa-route"></i>
                        </div>
                    </div>
                    <div class="card-header bg-white">
                        <ul class="nav nav-tabs card-header-tabs nav-justified">
                            <li class="nav-item">
                                <a class="nav-link active" href="#">Resumen</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Itinerario</a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body d-flex flex-column reduced-pt">
                        <h5 class="card-title">Ruta por la Isla de Cuento</h5>
                        <p class="card-text small-muted-text">Islas Canarias (Gran Canaria), 8 días</p>
                        <p class="card-text">A tu aire en coche</p>
                        <p class="card-text">Salida el 29/5/2025 desde Madrid</p>
                        <div class="mt-auto d-flex justify-content-between align-items-center pt-3">
                            <div class="card-bottom-icons">
                                <i class="fas fa-plane"></i>
                                <i class="fas fa-lock ms-2"></i>
                                <i class="fas fa-car ms-2"></i>
                            </div>
                            <div class="price-tag-container">
                                <span class="final-price">244€</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-img-top-container">
                        <img src="https://via.placeholder.com/350x233/E0E0E0/A0A0A0?text=Tenerife+Fuerteventura" class="card-img-top" alt="Tenerife y Fuerteventura">
                        <div class="card-img-overlay-icon">
                            <i class="fas fa-map-marked-alt"></i>
                        </div>
                    </div>
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title">Tenerife y Fuerteventura con coche de alquiler</h5>
                        <p class="card-text small-muted-text">Islas Canarias, 8 días</p>
                        <p class="card-text">A tu aire en coche</p>
                        <p class="card-text">Salida el 2/6/2025 desde Madrid</p>
                        <p class="card-text logiloco-text mb-2">LOGILOCO - 20€ dto. hasta el 02/06</p>
                        <div class="mt-auto d-flex justify-content-between align-items-center pt-2">
                            <div class="card-bottom-icons">
                                <i class="fas fa-plane"></i>
                                <i class="fas fa-lock ms-2"></i>
                                <i class="fas fa-car ms-2"></i>
                            </div>
                            <div class="price-tag-container">
                                <span class="original-price">581€</span>
                                <span class="final-price">561€</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card 4 -->
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-img-top-container">
                        <img src="https://via.placeholder.com/350x233/E0E0E0/A0A0A0?text=La+Palma+Lanzarote" class="card-img-top" alt="La Palma y Lanzarote">
                        <div class="card-img-overlay-icon">
                            <i class="fas fa-map-marked-alt"></i>
                        </div>
                    </div>
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title">La Palma y Lanzarote</h5>
                        <p class="card-text small-muted-text">Islas Canarias, 8 días</p>
                        <p class="card-text">A tu aire con estancia en playa</p>
                        <p class="card-text">Salida el 2/11/2025 desde Madrid</p>
                        <div class="mt-auto d-flex justify-content-between align-items-center pt-3">
                            <div class="card-bottom-icons">
                                <i class="fas fa-plane"></i>
                                <i class="fas fa-lock ms-2"></i>
                                <i class="fas fa-bus ms-2"></i>
                            </div>
                            <div class="price-tag-container">
                                <span class="discount-badge">-26%</span>
                                <span class="original-price">746€</span>
                                <span class="final-price">557€</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


            </div>
        </div>
    </section>
</main>
<footer>
    <div class="container">
        <p>© 2025 ViajesMundo. Todos los derechos reservados.</p>
    </div>
</footer>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
