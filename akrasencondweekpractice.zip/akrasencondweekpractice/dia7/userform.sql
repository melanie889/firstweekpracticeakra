
CREATE DATABASE IF NOT EXISTS userform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


USE userform;


CREATE TABLE IF NOT EXISTS usertable (
  id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(255) NOT NULL,
  email varchar(255) NOT NULL,
  password varchar(255) NOT NULL,
  code mediumint(50) NOT NULL,
  status text NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
